export default function Features() {
  return (
    <div className='p-10 grid md:grid-cols-3 gap-6'>
      <div>Cultivo sostenible</div>
      <div>Café de especialidad</div>
      <div>Origen colombiano</div>
    </div>
  )
}
