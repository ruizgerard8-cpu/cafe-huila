export default function ProductSection() {
  return (
    <div className='p-10 bg-white' id='producto'>
      <h2 className='text-2xl font-bold mb-4'>Nuestro Café</h2>
      <p>Café 100% arábica</p>
    </div>
  )
}
