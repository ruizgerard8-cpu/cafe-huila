export default function Contact() {
  return (
    <div className='p-10 bg-black text-white text-center'>
      <h2>Contacto</h2>
    </div>
  )
}
